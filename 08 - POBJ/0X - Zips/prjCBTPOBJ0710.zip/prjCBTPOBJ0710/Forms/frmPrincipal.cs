﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjCBTPOBJ0710
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }
        public cContaCorrente cContaCorrente { get; set; }
        private void btnConta_Click(object sender, EventArgs e)
        {
            this.cContaCorrente = new cContaCorrente(txtCc.Text.Trim()) { Saldo = 0 };
        }

        private void btnDepositar_Click(object sender, EventArgs e)
        {
            string Cc;
            int SGCC;
            try
            {
                Cc = txtCc.Text.Trim();
                SGCC = int.Parse(txtGeral.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                        ex.Message,
                        "Erro na busca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                );
                return;
            }
            if (String.IsNullOrEmpty(Cc) || this.cContaCorrente.NumeroCc != Cc)
            {
                MessageBox.Show(
                        "Conta Corrente não encontrada.",
                        "Erro na busca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                );
                return;
            }
            try
            {
                if (this.cContaCorrente.Depositar(SGCC))
                {
                    MessageBox.Show(
                            "Deposito efetuado com sucesso!",
                            "Sucesso",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                    );
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                            ex.Message,
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                    );
                return;
            }
            


        }

        private void btnSacar_Click(object sender, EventArgs e)
        {
            string Cc;
            int SGCC;
            try
            {
                Cc = txtCc.Text.Trim();
                SGCC = int.Parse(txtGeral.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                        ex.Message,
                        "Erro na busca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                );
                return;
            }
            if (String.IsNullOrEmpty(Cc) || this.cContaCorrente.NumeroCc != Cc)
            {
                MessageBox.Show(
                        "Conta Corrente não encontrada.",
                        "Erro na busca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                );
                return;
            }
            try
            {
                // Mostro? Idk
                int SaldoSacado = this.cContaCorrente.Sacar(SGCC);
                
                MessageBox.Show(
                        "Saque efetuado com sucesso!",
                        "Sucesso",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                );
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                            ex.Message,
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                    );
                return;
            }
        }

        private void btnSaldo_Click(object sender, EventArgs e)
        {
            string Cc;
            try
            {
                Cc = txtCc.Text.Trim();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                        ex.Message,
                        "Erro na busca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                );
                return;
            }
            if (String.IsNullOrEmpty(Cc) || this.cContaCorrente.NumeroCc != Cc)
            {
                MessageBox.Show(
                        "Conta Corrente não encontrada.",
                        "Erro na busca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                );
                return;
            }
            try
            {
                txtGeral.Text = this.cContaCorrente.ConsultarSaldo().ToString();
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                            ex.Message,
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                    );
                return;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
