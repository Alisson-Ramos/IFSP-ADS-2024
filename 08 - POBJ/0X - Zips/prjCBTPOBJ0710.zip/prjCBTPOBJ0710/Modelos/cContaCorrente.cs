﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class cContaCorrente
{
    // o Numero da Conta é string por conta de contas como 0001256
    // :)
    public cContaCorrente( string Cc)
    {
        NumeroCc = Cc;
    }

    public string NumeroCc { get; set; }
    public int Saldo { get; set; }

    public bool Depositar(int valorADepositar)
    {
        try
        {
            if (valorADepositar < 0)
                return false;

            Saldo += valorADepositar;

            return true;
        }
        catch (Exception e)
        {
            throw new Exception($"Houve um erro ao depositar.\n Erro: {e.Message}");
        }

        
    }

    public int Sacar(int valorASacar)
    {
        try
        {
            if (valorASacar > Saldo)
                throw new Exception($"Saldo Insuficiente para saque.");
         
            Saldo -= valorASacar;
            return valorASacar;
        }
        catch (Exception e)
        {
            throw new Exception($"Houve um erro no saque.\n Erro: {e.Message}");
        }
    }

    public int ConsultarSaldo()
    {
        try
        {
            return Saldo;
        }
        catch (Exception e)
        {
            throw new Exception($"Houve um erro ao consultar saldo.\n Erro: {e.Message}");
        }
    }
}

