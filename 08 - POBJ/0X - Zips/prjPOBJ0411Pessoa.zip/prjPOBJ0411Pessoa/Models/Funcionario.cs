﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjPessoaPOBJ.Modelos
{
    internal class Funcionario : Pessoa
    {
        public double Salario { get; set; }

        public Funcionario(string nome, int idade, double salario)
            : base(nome, idade)
        {
            this.Salario = salario;
        }

        public string Info()
        {
            return ($"Nome: {Nome} Idade em dias: {CalcularIdadeEmDias()} Salário: R$ {Salario}");
        }
    }
}
