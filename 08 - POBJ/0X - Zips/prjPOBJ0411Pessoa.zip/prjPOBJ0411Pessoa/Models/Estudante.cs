﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjPessoaPOBJ.Modelos
{
    internal class Estudante : Pessoa
    {
        public string Curso { get; set; }
        public Estudante(string nome, int idade, string curso) : base(nome, idade)
        {
            this.Curso = curso;
        }

        public string Info()
        {
            return ($"Nome: {Nome} Idade em dias: {CalcularIdadeEmDias()} Curso: {Curso}");
        }
    }
}
