﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjPessoaPOBJ.Modelos
{
    internal class Pessoa
    {
        #region Propriedades
        private string _nome;

		public string Nome
		{
			get { return _nome; }
			set { if (!String.IsNullOrEmpty(value)) _nome = value; }
		}
		private static int _idade;
 
        public static int Idade
		{
			get { return _idade; }
			set { if (value > 0) _idade = value; }
		}
        #endregion
        #region Métodos
		public static int CalcularIdadeEmDias()
		{
			return (Idade * 365);
        }
        #endregion
        #region Costrutores
        public Pessoa(string nome, int idade)
        {
            this.Nome = nome;
            Idade = idade;
        }
        #endregion
    }
}
