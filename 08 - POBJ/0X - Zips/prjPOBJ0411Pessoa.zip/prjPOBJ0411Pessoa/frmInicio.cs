﻿using prjPessoaPOBJ.Modelos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjPOBJ0411Pessoa
{
    public partial class frmInicio : Form
    {
        public frmInicio()
        {
            InitializeComponent();
        }

        private void btnTestarFun_Click(object sender, EventArgs e)
        {
            Funcionario funcionario = new Funcionario("Diego Mello", 19, 1406.00);

            MessageBox.Show(funcionario.Info());
        }

        private void btnTestarAlun_Click(object sender, EventArgs e)
        {
            Estudante estudante = new Estudante("Alisson", 19, "Análise e Desenvolvimento de Sistemas");

            MessageBox.Show(estudante.Info());
        }
    }
}
