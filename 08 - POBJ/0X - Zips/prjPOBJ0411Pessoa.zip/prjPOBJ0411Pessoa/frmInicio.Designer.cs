﻿namespace prjPOBJ0411Pessoa
{
    partial class frmInicio
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTestarFun = new System.Windows.Forms.Button();
            this.btnTestarAlun = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnTestarFun
            // 
            this.btnTestarFun.Location = new System.Drawing.Point(12, 12);
            this.btnTestarFun.Name = "btnTestarFun";
            this.btnTestarFun.Size = new System.Drawing.Size(124, 23);
            this.btnTestarFun.TabIndex = 0;
            this.btnTestarFun.Text = "Testar Funcionário";
            this.btnTestarFun.UseVisualStyleBackColor = true;
            this.btnTestarFun.Click += new System.EventHandler(this.btnTestarFun_Click);
            // 
            // btnTestarAlun
            // 
            this.btnTestarAlun.Location = new System.Drawing.Point(12, 41);
            this.btnTestarAlun.Name = "btnTestarAlun";
            this.btnTestarAlun.Size = new System.Drawing.Size(124, 23);
            this.btnTestarAlun.TabIndex = 1;
            this.btnTestarAlun.Text = "Testar Aluno";
            this.btnTestarAlun.UseVisualStyleBackColor = true;
            this.btnTestarAlun.Click += new System.EventHandler(this.btnTestarAlun_Click);
            // 
            // frmInicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(147, 75);
            this.Controls.Add(this.btnTestarAlun);
            this.Controls.Add(this.btnTestarFun);
            this.Name = "frmInicio";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnTestarFun;
        private System.Windows.Forms.Button btnTestarAlun;
    }
}

