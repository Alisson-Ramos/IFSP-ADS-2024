﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjCBTPOBJ07102
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        public Funcionario Funcionario { get; set; }
        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            Funcionario funcionario = new Funcionario()
            {
                Codigo = int.Parse(txtCPF.Text),
                Nome = txtNome.Text,
                SalarioBruto = int.Parse(txtBruto.Text)
            };
            this.Funcionario = funcionario;
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void btnSaldo_Click(object sender, EventArgs e)
        {
            try
            {
                txtNome.Text = this.Funcionario.Nome;
                txtBruto.Text = this.Funcionario.SalarioBruto.ToString();
                txtCPF.Text = this.Funcionario.Codigo.ToString();
                txtLiquido.Text = this.Funcionario.CalcularSalarioLiquido().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                            ex.Message,
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error
                    );
                return;
                throw;
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

    

