﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Funcionario
{
    public Funcionario()
    {
        _inss = 0.11;
    }

    public int Codigo { get; set; }
    public string Nome{ get; set; }
    public double SalarioBruto { get; set; }
    public double _inss { get; }


    public double CalcularSalarioLiquido()
    {
        return SalarioBruto - (_inss * SalarioBruto);
    }
}

